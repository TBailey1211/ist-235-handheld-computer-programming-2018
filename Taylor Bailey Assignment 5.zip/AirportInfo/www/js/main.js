window.onload = function(){
    document.
addEventListener("deviceready", init, false);
    init();
};

function init() {
    document.
getElementById('btnGetSchedule').
addEventListener('click', getSchedule, false);
}

function getSchedule() {
    $.ajax({url:"train.json", success: function(result){
        parseJSON(result);
    }});
    $("#schedule").html("");
}

function parseJSON(result) {
    var data = result;
    var arr = [Object.keys(data)];
    var northbound = result[arr[0]][0].Northbound;
    var output = "<h3>Northbound</h3>";
        output += "<table>";
        output += "<tr class='odd'><th>Train #</th><th>Time</th><th>Destination</th><th>Service</th><th>Status</th></tr>"
    
    for(var x = 0; x < northbound.length; x++)
    {
        if((x%2 == 0))
            {
                output += "<tr class='even'>";
            } else
            {
                output += "<tr class='odd'>";
            }
        var trainID = northbound[x].train_id;
        var destination = northbound[x].destination;
        var service = northbound[x].service_type;
        var status = northbound[x].status;
        var time = northbound[x].depart_time;
        time = time.substring(11, 17);
        output += "<td>" + trainID + "</td><td>" + time + "</td><td>" + destination + "</td>";
            output += "<td>" + service + "</td><td>" + status + "</td>";
            output += "</tr>";
    }
    output += "</table>";
    
    var southbound = result[arr[0]][1].Southbound;
    output += "<h3>Southbound</h3>";
    output += "<table>";
    output += "<tr class='odd'><th>Train #</th><th>Time</th><th>Destination</th><th>Service</th><th>Status</th></tr>"
    
    for(var x = 0; x < southbound.length; x++)
        {
            if((x%2 == 0))
                {
                    output += "<tr class='even'>";
                } else
                {
                    output += "<tr class='odd'>";
                }
                var trainID = southbound[x].train_id;
                var destination = southbound[x].destination;
                var service = southbound[x].service_type;
                var status = southbound[x].status;
                var time = southbound[x].depart_time;
            time = time.substring(11, 17);
            output += "<td>" + trainID + "</td><td>" + time + "</td><td>" + destination + "</td>";
            output += "<td>" + service + "</td><td>" + status + "</td>";
            output += "</tr>";
        }
    output += "</table>";
    $("#schedule").html(output);
}





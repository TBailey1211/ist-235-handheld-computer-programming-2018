window.onload = function(){
    alert("Application Running");
}